(function($) {
    "use strict";

    document.querySelectorAll("[data-year]").forEach((el) => {
        el.textContent = new Date().getFullYear();
    });

    var dropdown = document.querySelectorAll('[data-dropdown]');
    if (dropdown !== null) {
        dropdown.forEach(function(el) {
            window.addEventListener('click', function(e) {
                if (el.contains(e.target)) {
                    el.classList.toggle('active');
                    setTimeout(function() {
                        el.classList.toggle('animated');
                    }, 0);
                } else {
                    el.classList.remove('active');
                    el.classList.remove('animated');
                }
            });
        });
    }

    let actionsMenu = document.querySelector(".nav-bar-actions-menu"),
        actionsMenuBtn = document.querySelector(".actions-menu-btn"),
        actionsMenuClose = document.querySelector(".nav-bar-actions-menu .nav-bar-actions-close");

    if (actionsMenu) {
        actionsMenuBtn.onclick = () => {
            actionsMenu.classList.add("show");
            document.body.style.overflow = "hidden";
        };
        actionsMenuClose.onclick = () => {
            actionsMenu.classList.remove("show");
            document.body.removeAttribute("style");
        };
    }

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    let search = $(".search"),
        searchInput = $(".search .search-input input"),
        searchResults = $('.ajax-search-results');

    searchInput.on('input', function() {
        if (this.value.length > 0) {
            search.addClass("show");
            $.ajax({
                url: getConfig.baseURL + '/search',
                type: 'POST',
                data: {
                    lang: getConfig.lang,
                    search: $(this).val(),
                },
                success: function(response) {
                    searchResults.html(response);
                },
            });
        } else
            search.removeClass("show");
    });

    let searchV2 = document.querySelector(".search-v2"),
        searchBtn = document.querySelector(".search-btn"),
        searchV2Close = document.querySelector(".search-v2 .search-close"),
        searchV2Input = document.querySelector(".search-v2 .search-input input");

    if (searchBtn) {
        searchBtn.onclick = () => {
            searchV2.classList.add("active");
        };
        searchV2Close.onclick = () => {
            searchV2.classList.remove("active");
            searchV2Input.value = "";
            searchV2.classList.remove("show");
        };
    }

    let sidebar = document.querySelector(".page-content .sidebar"),
        sidebarToggle = document.querySelector(".sidebar-toggle");

    if (sidebarToggle) {
        sidebarToggle.onclick = () => {
            sidebar.classList.toggle("show");
        }
    }

    let articleRate = $('.article-rate'),
        articleFeedback = $('.article-feedback');

    articleRate.on('click', function() {
        const id = $(this).data('id');
        const action = $(this).data('action');
        $.ajax({
            url: getConfig.baseURL + '/' + getConfig.lang + '/article/rate',
            type: 'POST',
            data: {
                id: id,
                action: action,
            },
            success: function(response) {
                if ($.isEmptyObject(response.error)) {
                    articleFeedback.remove();
                    toastr.success(response.success);
                } else {
                    toastr.error(response.error);
                }
            },
        });
    });

})(jQuery);