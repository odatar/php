@if (request()->segment(2) == 'user')
    <script>
        "use strict";
        const config = {
            baseURL: "{{ url('/') }}",
            lang: "{{ getLang() }}",
            primaryColor: "{{ $settings['website_primary_color'] }}",
            secondaryColor: "{{ $settings['website_secondary_color'] }}",
            alertActionTitle: "{{ lang('Are you sure?', 'user') }}",
            alertActionText: "{{ lang('Confirm that you want do this action', 'user') }}",
            alertActionConfirmButton: "{{ lang('Confirm', 'user') }}",
            alertActionCancelButton: "{{ lang('Cancel', 'user') }}",
            ticketsMaxFilesError: "{{ lang('Max 5 files can be uploaded', 'tickets') }}",
        };
    </script>
@else
    <script>
        "use strict";
        const config = {
            baseURL: "{{ url('/') }}",
            lang: "{{ getLang() }}",
            countryCode: "{{ vIpInfo()->country_code == 'Unknown' ? 'US' : vIpInfo()->country_code }}",
        };
    </script>
@endauth
<script>
    "use strict";
    let configObjects = JSON.stringify(config),
        getConfig = JSON.parse(configObjects);
</script>
