@if ($SeoConfiguration)
    <meta name="title" content="{{ $settings['website_name'] }} - @yield('title')">
    <meta name="description"
content="@hasSection('description') @yield('description') @else {{ $SeoConfiguration->description }} @endif">
<meta name="keywords" content="{{ $SeoConfiguration->keywords }}">
<meta name="robots"
content="{{ $SeoConfiguration->robots_index . ', ' . $SeoConfiguration->robots_follow_links }}">
<meta name="language" content="{{ $SeoConfiguration->language->name }}">
<meta name="author" content="{{ $settings['website_name'] }}">
<meta property="og:url" content="{{ url()->current() }}">
<meta property="og:image" content="{{ asset($settings['website_social_image']) }}">
<meta property="og:site_name" content="{{ $settings['website_name'] }}">
<meta property="og:locale" content="{{ $SeoConfiguration->language->code }}">
<meta property="og:locale:alternate"
content="{{ $SeoConfiguration->language->code . '_' . strtoupper($SeoConfiguration->language->code) }}">
<meta property="og:type" content="website">
<meta property="og:title" content="{{ $settings['website_name'] }} - @yield('title')">
<meta property="og:description"
content="@hasSection('description') @yield('description') @else {{ $SeoConfiguration->description }} @endif">
<meta property="og:image:width" content="600">
<meta property="og:image:height" content="315">
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="{{ $settings['website_name'] }} - @yield('title')">
<meta name="twitter:image:src" content="{{ asset($settings['website_social_image']) }}">
<meta name="twitter:description"
content="@hasSection('description')@yield('description')@else{{ $SeoConfiguration->description }}@endif">
@endif
