@extends('frontend.layouts.grid')
@section('title', $category->name)
@section('footer', 'normal')
@section('content')
    <div class="page-content">
        @include('frontend.includes.sidebar')
        <div class="article">
            <nav class="mb-5">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ url('/') }}">{{ lang('Home') }}</a></li>
                    <li class="breadcrumb-item active">{{ $category->name }}</li>
                </ol>
            </nav>
            <div class="cate">
                <div class="cate-title">
                    <h3 class="fw-400">{{ $category->name }}</h3>
                </div>
                @foreach ($articles as $article)
                    <a href="{{ route('helpdesk.article', $article->slug) }}" class="cate-article">
                        <div class="cate-article-icon me-3">
                            <i class="far fa-file-alt"></i>
                        </div>
                        <div class="cate-article-info">
                            <p class="cate-article-title mb-0">{{ $article->title }}</p>
                            <p class="text-muted small mb-0">{{ $article->short_description }}</p>
                        </div>
                    </a>
                @endforeach
            </div>
            {{ $articles->links() }}
        </div>
    </div>
@endsection
