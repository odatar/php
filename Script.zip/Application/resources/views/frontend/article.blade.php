@extends('frontend.layouts.grid')
@section('title', $article->title)
@section('description', $article->short_description)
@section('footer', 'normal')
@section('content')
    <div class="page-content">
        @include('frontend.includes.sidebar')
        <div class="article">
            <nav class="mb-5">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="{{ url('/') }}">{{ lang('Home') }}</a></li>
                    <li class="breadcrumb-item"><a
                            href="{{ route('helpdesk.category', $article->category->slug) }}">{{ $article->category->name }}</a>
                    </li>
                    <li class="breadcrumb-item active">{{ $article->title }}</li>
                </ol>
            </nav>
            <div class="d-flex flex-column align-items-start mb-4">
                <h2 class="mb-0 border-bottom py-3 fw-400">{{ $article->title }}</h2>
                <div class="my-4 text-justify">
                    {!! $article->content !!}
                </div>
            </div>
            <div class="article-feedback border-top text-center py-5">
                <p>{{ lang('Was this article helpful?', 'help center') }}</p>
                <div class="d-flex justify-content-center">
                    <button class="article-rate btn btn-outline-secondary text-uppercase me-3"
                        data-id="{{ encrypt($article->id) }}" data-action="1">
                        <i class="fa fa-check me-1"></i> {{ lang('Yes', 'help center') }}
                    </button>
                    <button class="article-rate btn btn-outline-secondary text-uppercase"
                        data-id="{{ encrypt($article->id) }}" data-action="0">
                        <i class="fa fa-times me-1"></i> {{ lang('No', 'help center') }}
                    </button>
                </div>
            </div>
        </div>
    </div>
@endsection
