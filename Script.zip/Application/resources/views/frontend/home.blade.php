@extends('frontend.layouts.front')
@section('title', $SeoConfiguration->title ?? '')
@section('content')
    <section class="section-content">
        <div class="container-lg">
            <div class="section-content-title mb-4 text-center">
                <h2 class="mb-0">{{ lang('Welcome to Fowtickets Help Center!', 'home page') }}</h2>
            </div>
            <p class="section-content-text col-lg-6 mx-auto text-center">
                {{ lang('We have provided answers to a lot of common questions below so that you can learn how to get your tasks completed', 'home page') }}.
            </p>
            <div class="row row-cols-1 row-cols-md-2 row-cols-xl-3 g-4 mt-4 mt-lg-5">
                @foreach ($data as $item)
                    <div class="col">
                        <div class="questions">
                            <div class="questions-title mb-3">
                                <h5 class="mb-2">{{ $item['categories']->name }}
                                    ({{ count($item['articles']) }})</h5>
                            </div>
                            <div class="questions-content">
                                @foreach (array_slice($item['articles'], 0, 5) as $article)
                                    <a href="{{ route('helpdesk.article', $article->slug) }}"><i
                                            class="far fa-file-alt fa-lg me-2"></i>{{ $article->title }}</a>
                                @endforeach
                            </div>
                            <div class="d-flex justify-content-end mt-4">
                                <a href="{{ route('helpdesk.category', $item['categories']->slug) }}">{{ lang('View All', 'home page') }}<i
                                        class="fas fa-angle-right ms-1"></i></a>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </section>
    @if ($popularArticles->count() > 0)
        <section class="section-content">
            <div class="container-lg">
                <div class="section-content-title mb-4">
                    <h2 class="mb-0">{{ lang('Popular Articles', 'home page') }}</h2>
                </div>
                <div class="row row-cols-1 row-cols-lg-2 gx-3 mt-4">
                    @foreach ($popularArticles as $popularArticle)
                        <div class="col">
                            <a href="{{ route('helpdesk.article', $popularArticle->slug) }}"
                                class="popular">{{ $popularArticle->title }}</a>
                        </div>
                    @endforeach
                </div>
            </div>
        </section>
    @endif
    <section class="section-content request-style">
        <div class="container-lg">
            <div class="request text-center">
                <h3>{{ lang('Still no luck? We can help!', 'home page') }}</h3>
                <p>{{ lang('Contact us and we will get back to you as soon as possible', 'home page') }}.</p>
                <a href="{{ route('user.tickets.create') }}"
                    class="btn btn-primary btn-lg">{{ lang('Open a Ticket', 'home page') }}</a>
            </div>
        </div>
    </section>
@endsection
