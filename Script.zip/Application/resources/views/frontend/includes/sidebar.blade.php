<aside class="sidebar" data-simplebar>
    @foreach ($data as $item)
        <div class="sidebar-links @if (request()->segment(2) == 'category' && request()->segment(3) == $item['categories']->slug) active @endif">
            <p class="sidebar-links-title h6 mb-4">{{ $item['categories']->name }}</p>
            @foreach ($item['articles'] as $article)
                <a href="{{ route('helpdesk.article', $article->slug) }}"
                    class="sidebar-links-item @if (request()->segment(2) == 'article' && request()->segment(3) == $article->slug) active @endif">{{ $article->title }}</a>
            @endforeach
        </div>
    @endforeach
</aside>
