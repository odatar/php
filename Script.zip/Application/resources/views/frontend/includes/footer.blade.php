<footer class="footer mt-auto @yield('footer')">
    <div class="container-lg">
        <div class="footer-links">
            <div class="row row-cols-auto justify-content-center gx-0 gy-3">
                @foreach ($footerMenuLinks as $footerMenuLink)
                    <div class="col">
                        <a href="{{ $footerMenuLink->link }}">{{ $footerMenuLink->name }}</a>
                    </div>
                @endforeach
            </div>
        </div>
        <p class="copyright mb-0">&copy; <span data-year></span> {{ $settings['website_name'] }} -
            {{ lang('All rights reserved') }}.</p>
    </div>
</footer>
