<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    @include('frontend.includes.head')
    @include('frontend.includes.styles')
</head>
<style>
    .toast-top-right {
        top: 90px;
    }

</style>

<body class="page bg-white">
    @include('frontend.configurations.config')
    <header class="header">
        <nav class="nav-bar article-style">
            <div class="container-fluid d-flex align-items-center h-100">
                <div class="sidebar-toggle me-3 d-lg-none">
                    <i class="fa fa-bars"></i>
                </div>
                <a class="logo w-auto" href="{{ url('/') }}">
                    <img src="{{ asset($settings['website_light_logo']) }}" alt="{{ $settings['website_name'] }}" />
                </a>
                <div class="search search-v2 me-4">
                    <div class="search-input">
                        <form action="{{ url('/') }}" method="GET">
                            <input type="text" name="q" placeholder="{{ lang('Search') }}..."
                                value="{{ request()->input('q') ?? '' }}" autocomplete="off" required />
                            <div class="search-icon">
                                <i class="fa fa-search d-none d-lg-block"></i>
                                <div class="search-close d-lg-none">
                                    <i class="fa fa-times"></i>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="search-results" data-simplebar>
                        <div class="ajax-search-results"></div>
                    </div>
                </div>
                <div class="nav-bar-actions ms-auto">
                    <div class="search-btn me-4 d-lg-none"><i class="fa fa-search"></i></div>
                    @auth
                        <div class="user-menu light ms-auto ms-xl-2" data-dropdown>
                            <div class="user-avatar">
                                <img src="{{ asset(userAuthInfo()->avatar) }}" alt="{{ userAuthInfo()->name }}">
                            </div>
                            <p class="user-name mb-0 ms-2 d-none d-sm-block">{{ userAuthInfo()->name }}</p>
                            <div class="nav-bar-user-dropdown-icon ms-2 d-none d-sm-block">
                                <i class="fas fa-chevron-down fa-xs"></i>
                            </div>
                            <div class="user-menu-dropdown">
                                <a class="user-menu-link" href="{{ route('user.tickets') }}">
                                    <i class="far fa-life-ring"></i> {{ lang('My Tickets', 'user') }}
                                </a>
                                <a class="user-menu-link" href="{{ route('user.settings') }}">
                                    <i class="fa fa-cog"></i> {{ lang('settings', 'user') }}
                                </a>
                                <form class="d-inline" action="{{ route('logout') }}" method="POST">
                                    @csrf
                                    <button class="user-menu-link text-danger">
                                        <i class="fa fa-power-off"></i> {{ lang('Logout', 'user') }}
                                    </button>
                                </form>
                            </div>
                        </div>
                    @else
                        <a href="{{ route('login') }}" class="btn btn-light btn-lg">{{ lang('Sign In', 'user') }}</a>
                        @if ($settings['website_registration_status'])
                            <a href="{{ route('register') }}"
                                class="btn btn-outline-light btn-lg d-none d-sm-inline-block">{{ lang('Sign Up', 'user') }}</a>
                        @endif
                    @endauth
                </div>
            </div>
        </nav>
    </header>
    @yield('content')
    @include('frontend.includes.footer')
    @include('frontend.configurations.widgets')
    @include('frontend.includes.scripts')
</body>

</html>
