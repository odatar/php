<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */

Route::group(['middleware' => ['notInstalled', 'admin.locale'], 'prefix' => 'admin', 'namespace' => 'Backend'], function () {
    Route::name('admin.')->namespace('Auth')->group(function () {
        Route::get('/', 'LoginController@redirectToLogin')->name('index');
        Route::get('login', 'LoginController@showLoginForm')->name('login');
        Route::post('login', 'LoginController@login')->name('login.store');
        Route::get('password/reset', 'ForgotPasswordController@showLinkRequestForm')->name('password.reset');
        Route::post('password/reset', 'ForgotPasswordController@sendResetLinkEmail');
        Route::get('password/reset/{token}', 'ResetPasswordController@showResetForm')->name('password.reset.link');
        Route::post('password/reset/change', 'ResetPasswordController@reset')->name('password.reset.change');
        Route::post('logout', 'LoginController@logout')->name('logout');
    });
    Route::group(['middleware' => 'admin'], function () {
        Route::group(['namespace' => 'Dashboard'], function () {
            Route::get('dashboard', 'DashboardController@index')->name('admin.dashboard');
            Route::get('dashboard/charts/users', 'DashboardController@usersChartData')->middleware('ajax.only');
            Route::get('dashboard/charts/tickets', 'DashboardController@ticketsChartData')->middleware('ajax.only');
        });
        Route::name('admin.')->namespace('Notifications')->group(function () {
            Route::get('notifications', 'NotificationController@index')->name('notifications');
            Route::get('notifications/view/{id}', 'NotificationController@view')->name('notifications.view');
            Route::get('notifications/readall', 'NotificationController@readAll')->name('notifications.readall');
            Route::delete('notifications/deleteallread', 'NotificationController@deleteAllRead')->name('notifications.deleteallread');
        });
        Route::group(['namespace' => 'Users'], function () {
            Route::name('users.')->prefix('users')->group(function () {
                Route::post('{id}/edit/change/avatar', 'UserController@changeAvatar');
                Route::delete('{id}/edit/delete/avatar', 'UserController@deleteAvatar')->name('deleteAvatar');
                Route::get('{id}/edit/logs', 'UserController@logs')->name('logs');
                Route::get('{id}/edit/logs/get/{log_id}', 'UserController@getLogs')->middleware('ajax.only');
                Route::post('{id}/edit/sentmail', 'UserController@sendMail')->name('sendmail');
                Route::get('logs/{ip}', 'UserController@logsByIp')->name('logsbyip');
            });
            Route::resource('users', 'UserController');
        });
        Route::prefix('navigation')->namespace('Navigation')->name('admin.')->group(function () {
            Route::post('footerMenu/sort', 'FooterMenuController@sort')->name('footerMenu.sort');
            Route::resource('footerMenu', 'FooterMenuController');
        });
        Route::group(['prefix' => 'helpdesk', 'namespace' => 'HelpDesk'], function () {
            Route::get('categories/slug', 'CategoryController@slug')->name('categories.slug');
            Route::resource('categories', 'CategoryController');
            Route::get('articles/slug', 'ArticleController@slug')->name('articles.slug');
            Route::get('articles/categories/{lang}', 'ArticleController@getCategories')->middleware('ajax.only');
            Route::resource('articles', 'ArticleController');
        });
        Route::group(['prefix' => 'support', 'namespace' => 'Support'], function () {
            Route::name('tickets.')->prefix('tickets')->group(function () {
                Route::get('create/get/user', 'TicketController@getUser');
                Route::get('status/{status}', 'TicketController@index')->name('status');
                Route::get('{ticket_number}/close', 'TicketController@closeTicket')->name('close');
                Route::post('{ticket_number}/reply', 'TicketController@ticketReply')->name('reply');
                Route::get('download/{ticket_number}/{id}', 'TicketController@downloadAttachments')->name('download');
            });
            Route::resource('tickets', 'TicketController');
        });
        Route::group(['prefix' => 'settings', 'namespace' => 'Settings'], function () {
            Route::name('admin.')->group(function () {
                Route::view('/', 'backend.settings.index')->name('settings');
                Route::get('general', 'GeneralController@index')->name('settings.general');
                Route::post('general/update', 'GeneralController@update')->name('settings.general.update');
                Route::get('smtp', 'SmtpController@index')->name('settings.smtp');
                Route::post('smtp/update', 'SmtpController@update')->name('settings.smtp.update');
                Route::post('smtp/test', 'SmtpController@test')->name('settings.smtp.test');
                Route::get('extensions', 'ExtensionController@index')->name('settings.extensions');
                Route::post('extensions/update', 'ExtensionController@update')->name('settings.extensions.update');
            });
            Route::get('pages/slug', 'PageController@slug')->name('pages.slug');
            Route::resource('pages', 'PageController');
            Route::resource('admins', 'AdminController');
            Route::prefix('languages')->group(function () {
                Route::post('{id}/default', 'LanguageController@setDefault')->name('language.default');
                Route::post('{id}/update', 'LanguageController@translateUpdate')->name('translates.update');
                Route::get('translate/{code}', 'LanguageController@translate')->name('language.translate');
                Route::get('translate/{code}/{group}', 'LanguageController@translate')->name('language.translate.group');
            });
            Route::resource('languages', 'LanguageController');
            Route::resource('seo', 'SeoController');
        });
        Route::name('admin.')->prefix('additional')->namespace('Additional')->group(function () {
            Route::get('cache', 'CacheController@index')->name('additional.cache');
            Route::get('custom-css', 'CustomCssController@index')->name('additional.css');
            Route::post('custom-css/update', 'CustomCssController@update')->name('additional.css.update');
            Route::get('popup-notice', 'PopupNoticeController@index')->name('additional.notice');
            Route::post('popup-notice/update', 'PopupNoticeController@update')->name('additional.notice.update');
        });
        Route::name('admin.')->prefix('account')->namespace('Account')->group(function () {
            Route::get('details', 'SettingsController@detailsForm')->name('account.details');
            Route::get('security', 'SettingsController@securityForm')->name('account.security');
            Route::post('details/update', 'SettingsController@detailsUpdate')->name('account.details.update');
            Route::post('security/update', 'SettingsController@securityUpdate')->name('account.security.update');
        });
    });
});
Route::prefix('user')->namespace('Frontend\User')->middleware(['notInstalled', 'UserStatusCheck', 'auth', 'verified'])->group(function () {
    Route::get('tickets/download/{ticket_number}/{id}', 'TicketController@downloadAttachments')->name('user.tickets.download');
});
Route::group([
    'prefix' => LaravelLocalization::setLocale(),
    'middleware' => ['notInstalled', 'localizationRedirect', 'localeSessionRedirect', 'UserStatusCheck'],
], function () {
    Auth::routes(['verify' => true]);
    Route::group(['namespace' => 'Frontend\User\Auth'], function () {
        Route::get('login', 'LoginController@showLoginForm')->name('login');
        Route::post('login', 'LoginController@login');
        Route::get('login/{provider}', 'LoginController@redirectToProvider')->name('provider.login');
        Route::get('login/{provider}/callback', 'LoginController@handleProviderCallback')->name('provider.callback');
        Route::post('logout', 'LoginController@logout')->name('logout');
        Route::middleware(['disable.registration'])->group(function () {
            Route::get('register', 'RegisterController@showRegistrationForm')->name('register');
            Route::post('register', 'RegisterController@register')->middleware('check.registration');
            Route::get('register/complete/{token}', 'RegisterController@showCompleteForm')->name('complete.registration');
            Route::post('register/complete/{token}', 'RegisterController@complete')->middleware('check.registration');
        });
        Route::get('password/reset', 'ForgotPasswordController@showLinkRequestForm')->name('password.request');
        Route::post('password/email', 'ForgotPasswordController@sendResetLinkEmail')->name('password.email');
        Route::get('password/reset/{token}', 'ResetPasswordController@showResetForm')->name('password.reset');
        Route::post('password/reset', 'ResetPasswordController@reset')->name('password.update');
        Route::get('password/confirm', 'ConfirmPasswordController@showConfirmForm')->name('password.confirm');
        Route::post('password/confirm', 'ConfirmPasswordController@confirm');
        Route::get('email/verify', 'VerificationController@show')->name('verification.notice');
        Route::post('email/verify/email/change', 'VerificationController@changeEmail')->name('change.email');
        Route::get('email/verify/{id}/{hash}', 'VerificationController@verify')->name('verification.verify');
        Route::post('email/resend', 'VerificationController@resend')->name('verification.resend');
    });
    Route::group(['namespace' => 'Frontend\User\Auth', 'middleware' => ['auth', 'verified']], function () {
        Route::get('checkpoint/2fa/verify', 'CheckpointController@show2FaVerifyForm')->name('2fa.verify');
        Route::post('checkpoint/2fa/verify', 'CheckpointController@verify2fa');
    });
    Route::group(['prefix' => 'user', 'namespace' => 'Frontend\User', 'middleware' => ['auth', 'verified', '2fa.verify']], function () {
        Route::get('/', function () {
            return redirect()->route('user.tickets');
        })->name('user');
        Route::name('user.')->group(function () {
            Route::prefix('notifications')->group(function () {
                Route::get('/', 'NotificationController@index')->name('notifications');
                Route::get('view/{id}', 'NotificationController@view')->name('notifications.view');
                Route::get('readall', 'NotificationController@readAll')->name('notifications.readall');
            });
            Route::prefix('tickets')->group(function () {
                Route::get('/', 'TicketController@index')->name('tickets');
                Route::get('create', 'TicketController@create')->name('tickets.create');
                Route::post('create/store', 'TicketController@store')->name('tickets.store');
                Route::get('{ticket_number}', 'TicketController@view')->name('tickets.view');
                Route::post('{ticket_number}/reply', 'TicketController@ticketReply')->name('tickets.reply');
                Route::get('status/{status}', 'TicketController@index')->name('tickets.status');
            });
            Route::prefix('settings')->group(function () {
                Route::get('/', 'SettingsController@index')->name('settings');
                Route::post('details/update', 'SettingsController@detailsUpdate')->name('settings.details.update');
                Route::post('details/mobile/update', 'SettingsController@mobileUpdate')->name('settings.details.mobile.update');
                Route::get('password', 'SettingsController@password')->name('settings.password');
                Route::post('password/update', 'SettingsController@passwordUpdate')->name('settings.password.update');
                Route::get('2fa', 'SettingsController@towFactor')->name('settings.2fa');
                Route::post('2fa/enable', 'SettingsController@towFactorEnable')->name('settings.2fa.enable');
                Route::post('2fa/disabled', 'SettingsController@towFactorDisable')->name('settings.2fa.disable');
            });
        });
    });
    Route::group(['namespace' => 'Frontend'], function () {
        Route::get('/', 'HomeController@index')->name('home');
        Route::post('search', 'HomeController@search');
        Route::get('category/{slug}', 'HelpdeskController@category')->name('helpdesk.category');
        Route::get('article/{slug}', 'HelpdeskController@article')->name('helpdesk.article');
        Route::post('article/rate', 'HelpdeskController@articleRate');
        Route::get('cookie/accept', 'ExtraController@cookie')->middleware('ajax.only');
        Route::get('popup/close', 'ExtraController@popup')->middleware('ajax.only');
        Route::get('{slug}', 'PageController@index')->name('page');
    });
});
