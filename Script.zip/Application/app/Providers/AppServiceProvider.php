<?php

namespace App\Providers;

use App\Models\AdminNotification;
use App\Models\Article;
use App\Models\Category;
use App\Models\FooterMenu;
use App\Models\Language;
use App\Models\SeoConfiguration;
use App\Models\SupportTicket;
use App\Models\UserNotification;
use Config;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;
use Mcamara\LaravelLocalization\Facades\LaravelLocalization;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        if (env('VIRONEER_SYSTEMSTATUS')) {

            Paginator::useBootstrap();
            Config::set('laravellocalization.supportedLocales', getSupportedLocales());

            view()->composer('*', function ($view) {
                $view->with(['settings' => settings(), 'additionals' => additionals(), 'countries' => countries()]);
            });

            if (request()->segment(1) != "admin") {
                if (settings('website_force_ssl_status')) {
                    $this->app['request']->server->set('HTTPS', true);
                }

                view()->composer('*', function ($view) {
                    $languages = Language::all();
                    $view->with('languages', $languages);
                });

                view()->composer(['frontend.configurations.metaTags', 'frontend.home'], function ($view) {
                    $lang = LaravelLocalization::getCurrentLocale();
                    $SeoConfiguration = SeoConfiguration::where('lang', $lang)->with('language')->first();
                    $view->with('SeoConfiguration', $SeoConfiguration);
                });

                view()->composer('frontend.user.layouts.dash', function ($view) {
                    $userNotifications = UserNotification::where('user_id', userAuthInfo()->id)->orderbyDesc('id')->limit(20)->get();
                    $unreadUserNotifications = UserNotification::where([['status', 0], ['user_id', userAuthInfo()->id]])->get()->count();
                    $repliedTicketsCount = SupportTicket::where([['status', 2], ['user_id', userAuthInfo()->id]])->get()->count();
                    $view->with([
                        'userNotifications' => $userNotifications,
                        'unreadUserNotifications' => $unreadUserNotifications,
                        'repliedTicketsCount' => $repliedTicketsCount,
                    ]);
                });

                view()->composer('frontend.includes.footer', function ($view) {
                    $footerMenuLinks = FooterMenu::where('lang', getLang())->orderBy('sort_id', 'asc')->get();
                    $view->with([
                        'footerMenuLinks' => $footerMenuLinks,
                    ]);
                });
                view()->composer('frontend.includes.sidebar', function ($view) {
                    $categories = Category::where('lang', getLang())->get();
                    $data = [];
                    foreach ($categories as $category) {
                        $articleList = [];
                        $articlesQuery = Article::where([['category_id', $category->id], ['lang', getLang()]])->select('title', 'slug')->get();
                        foreach ($articlesQuery as $singleArticle) {
                            $articleList[] = $singleArticle;
                        }
                        $data[] = ['categories' => $category, 'articles' => $articleList];
                    }
                    $view->with([
                        'data' => $data,
                    ]);
                });
            }

            if (request()->segment(1) == "admin") {

                view()->composer('*', function ($view) {
                    $adminLanguages = Language::all();
                    $view->with('adminLanguages', $adminLanguages);
                });

                view()->composer('backend.includes.header', function ($view) {
                    $adminNotifications = AdminNotification::orderbyDesc('id')->limit(20)->get();
                    $unreadAdminNotifications = AdminNotification::where('status', 0)->get()->count();
                    $view->with(['adminNotifications' => $adminNotifications, 'unreadAdminNotifications' => $unreadAdminNotifications]);
                });
                view()->composer('backend.includes.sidebar', function ($view) {
                    $ticketsNeedsAction = SupportTicket::where('status', 0)->OrWhere('status', 1)->get()->count();
                    $view->with('ticketsNeedsAction', $ticketsNeedsAction);
                });
            }
        }
    }
}
