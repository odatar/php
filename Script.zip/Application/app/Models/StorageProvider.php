<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StorageProvider extends Model
{
    use HasFactory;
    // Disable timestamps
    public $timestamps = false;
    /**
     * Get providers by key
     */
    public static function selectStorageProviders($key)
    {
        $provider = StorageProvider::where('key', $key)->first();
        if ($provider) {
            return $provider->value;
        }
        return false;
    }

    /**
     * Update providers from table.
     */
    public static function updateStorageProviders($key, $value)
    {
        $provider = StorageProvider::where('key', $key)->first();
        if ($provider) {
            $provider->value = $value;
            return $provider->save();
        }
        return false;
    }
}
