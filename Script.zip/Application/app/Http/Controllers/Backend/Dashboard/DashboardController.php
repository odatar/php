<?php

namespace App\Http\Controllers\Backend\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\Article;
use App\Models\Page;
use App\Models\SupportTicket;
use App\Models\User;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function index()
    {
        $users = User::orderbyDesc('id')->limit(6)->get();
        $totalUsers = User::all()->count();
        $totalTickets = SupportTicket::all()->count();
        $totalPages = Page::all()->count();
        $totalArticles = Article::all()->count();
        $openedTicketsCount = SupportTicket::where('status', 0)->get()->count();
        $answeredTicketsCount = SupportTicket::where('status', 1)->get()->count();
        $repliedTicketsCount = SupportTicket::where('status', 2)->get()->count();
        $closedTicketsCount = SupportTicket::where('status', 3)->get()->count();
        return view('backend.dashboard.index', [
            'users' => $users,
            'totalUsers' => $totalUsers,
            'totalTickets' => $totalTickets,
            'totalPages' => $totalPages,
            'totalArticles' => $totalArticles,
            'openedTicketsCount' => $openedTicketsCount,
            'answeredTicketsCount' => $answeredTicketsCount,
            'repliedTicketsCount' => $repliedTicketsCount,
            'closedTicketsCount' => $closedTicketsCount,
        ]);
    }

    public function usersChartData()
    {
        $startDate = Carbon::today()->subDays(7);
        $endDate = Carbon::yesterday();
        $dates = chartDates($startDate, $endDate);
        $countWeeklyUsers = User::where('created_at', '>=', Carbon::today()->subDays(7))->get()->count();
        $usersRecord = User::where('created_at', '>=', Carbon::today()->subDays(7))
            ->selectRaw('DATE(created_at) as date, COUNT(*) as count')
            ->groupBy('date')
            ->pluck('count', 'date');
        $usersRecordData = $dates->merge($usersRecord);
        $usersChartLabels = [];
        $usersChartData = [];
        foreach ($usersRecordData as $key => $value) {
            $usersChartLabels[] = Carbon::parse($key)->format('d F');
            $usersChartData[] = $value;
        }
        return [
            'usersChartLabels' => $usersChartLabels,
            'usersChartData' => $usersChartData,
            'countWeeklyUsers' => $countWeeklyUsers,
        ];
    }

    public function ticketsChartData()
    {
        $startDate = Carbon::now()->startOfMonth();
        $endDate = Carbon::now()->endOfMonth();
        $dates = chartDates($startDate, $endDate);
        $countMonthlyTickets = SupportTicket::where('created_at', '>=', Carbon::now()->startOfMonth())->get()->count();
        $ticketsRecord = SupportTicket::where('created_at', '>=', Carbon::now()->startOfMonth())
            ->selectRaw('DATE(created_at) as date, COUNT(*) as count')
            ->groupBy('date')
            ->pluck('count', 'date');
        $ticketsRecordData = $dates->merge($ticketsRecord);
        $ticketsChartLabels = [];
        $ticketsChartData = [];
        foreach ($ticketsRecordData as $key => $value) {
            $ticketsChartLabels[] = Carbon::parse($key)->format('d M');
            $ticketsChartData[] = $value;
        }
        return [
            'ticketsChartLabels' => $ticketsChartLabels,
            'ticketsChartData' => $ticketsChartData,
            'countMonthlyTickets' => $countMonthlyTickets,
        ];
    }
}
