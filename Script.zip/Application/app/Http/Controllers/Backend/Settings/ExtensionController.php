<?php

namespace App\Http\Controllers\Backend\Settings;

use App\Http\Controllers\Controller;
use App\Models\Settings;
use Illuminate\Http\Request;
use Validator;

class ExtensionController extends Controller
{
    public function index()
    {
        return view('backend.settings.extensions.index');
    }

    public function update(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'ext_google_captcha_site_key' => ['max:255'],
            'ext_google_captcha_secret_key' => ['max:255'],
            'ext_google_analytics_code' => ['max:100'],
            'ext_tawk_code' => ['max:150'],
            'ext_facebook_client_id' => ['max:100'],
            'ext_facebook_client_secret' => ['max:255'],
        ]);

        if (isset($validator) && $validator->fails()) {
            foreach ($validator->errors()->all() as $error) {toastr()->error($error);}
            return back();
        }
        $settings = Settings::whereIn('key', [
            'ext_google_captcha_site_key',
            'ext_google_captcha_secret_key',
            'ext_google_analytics_code',
            'ext_tawk_code',
            'ext_disqus_status',
            'ext_facebook_client_id',
            'ext_facebook_client_secret',
        ])->get();
        foreach ($settings as $setting) {
            $key = $setting->key;
            $setting->value = $request->$key;
            $setting->save();
        }
        setEnv('FACEBOOK_CLIENT_ID', $request->ext_facebook_client_id);
        setEnv('FACEBOOK_CLIENT_SECRET', $request->ext_facebook_client_secret);
        setEnv('NOCAPTCHA_SITEKEY', $request->ext_google_captcha_site_key);
        setEnv('NOCAPTCHA_SECRET', $request->ext_google_captcha_secret_key);
        toastr()->success(__('Updated Successfully'));
        return back();
    }
}
