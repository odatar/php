<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Article;
use App\Models\Category;
use Illuminate\Http\Request;

class HelpdeskController extends Controller
{
    public function category($slug)
    {
        $category = Category::where([['slug', $slug], ['lang', getLang()]])->first();
        if ($category) {
            $articles = Article::where([['category_id', $category->id], ['lang', getLang()]])->paginate(10);
            $category->increment('views');
            return view('frontend.category', ['category' => $category, 'articles' => $articles]);
        } else {
            return redirect()->route('home');
        }
    }

    public function article($slug)
    {
        $article = Article::where([['slug', $slug], ['lang', getLang()]])->with('category')->first();
        if ($article) {
            $article->increment('views');
            return view('frontend.article', ['article' => $article]);
        } else {
            return redirect()->route('home');
        }
    }

    public function articleRate(Request $request)
    {
        $article = Article::find(decrypt($request->id));
        if (!$article) {
            return response()->json(['error' => lang('Article not exists', 'help center')]);
        }
        if ($request->action == 0) {
            $article->increment('dislikes');
        }
        if ($request->action == 1) {
            $article->increment('likes');
        }
        return response()->json(['success' => lang('Thanks for your feedback', 'help center')]);
    }
}
