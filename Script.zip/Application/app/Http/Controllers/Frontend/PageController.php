<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Page;

class PageController extends Controller
{
    public function index($slug)
    {
        $hideSearch = true;
        $page = Page::where([['slug', $slug], ['lang', getLang()]])->first();
        if ($page) {
            $page->increment('views');
            return view('frontend.page', ['page' => $page, 'hideSearch' => $hideSearch]);
        } else {
            return redirect()->route('home');
        }
    }
}
