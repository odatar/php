<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Article;
use App\Models\Category;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index(Request $request)
    {
        if (!$request->has('q')) {
            $popularArticles = Article::orderbyDesc('views')->where('lang', getLang())->select('title', 'slug')->limit(12)->get();
            $categories = Category::where('lang', getLang())->get();
            $data = [];
            foreach ($categories as $category) {
                $articleList = [];
                $articlesQuery = Article::where([['category_id', $category->id], ['lang', getLang()]])->select('title', 'slug')->get();
                foreach ($articlesQuery as $singleArticle) {
                    $articleList[] = $singleArticle;
                }
                $data[] = ['categories' => $category, 'articles' => $articleList];
            }
            return view('frontend.home', ['data' => $data, 'popularArticles' => $popularArticles]);
        } else {
            $q = $request->q;
            $articles = Article::where([['title', 'like', '%' . $q . '%'], ['lang', getLang()]])
                ->OrWhere([['slug', 'like', '%' . $q . '%'], ['lang', getLang()]])
                ->OrWhere([['content', 'like', '%' . $q . '%'], ['lang', getLang()]])
                ->OrWhere([['short_description', 'like', '%' . $q . '%'], ['lang', getLang()]])
                ->select('slug', 'title', 'short_description')
                ->get();
            return view('frontend.search', ['articles' => $articles]);
        }
    }

    public function search(Request $request)
    {
        $q = $request->search;
        $lang = $request->lang;
        $articles = Article::where([['lang', $lang], ['title', 'like', '%' . $q . '%']])
            ->OrWhere([['lang', $lang], ['slug', 'like', '%' . $q . '%']])
            ->OrWhere([['lang', $lang], ['content', 'like', '%' . $q . '%']])
            ->OrWhere([['lang', $lang], ['short_description', 'like', '%' . $q . '%']])
            ->select('slug', 'title')
            ->get();

        $output = '';
        if ($articles->count() > 0) {
            foreach ($articles as $article) {
                $output .= '<a class="search-item" href="' . route('helpdesk.article', $article->slug) . '"> <i class="far fa-file-alt fa-lg me-2"></i>' . $article->title . '</a>';
            }
        } else {
            $output .= '<div class="empty">' . lang("No results found") . '</div>';
        }
        return $output;
    }
}
