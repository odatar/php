<?php

namespace App\Http\Middleware;

use App;
use Closure;
use Illuminate\Http\Request;
use Session;

class AdminLocalization
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        $admin_lang = "en";
        if (session()->has('admin_locale') && session('admin_locale') == 'en') {
            App::setLocale(session('admin_locale'));
            App::setLocale(config('app.locale'));
        } else {
            Session::put('admin_locale', $admin_lang);
        }

        return $next($request);
    }
}
