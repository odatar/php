<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class NewTicketReplyNotification extends Notification
{
    use Queueable;
    private $details;
    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($details)
    {
        $this->details = $details;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        $url = route('user.tickets.view', $this->details['ticketNumber']);

        return (new MailMessage)
            ->subject(str_replace('[TICKET_NUMBER]', $this->details['ticketNumber'], '[Ticket#[TICKET_NUMBER]] New Reply'))
            ->line('You are receiving this message because you had a ticket open and there is a new reply on it you can click here to view it directly.')
            ->action('View Ticket', $url)
            ->line('You can reply directly on the ticket by going to your account then my tickets.');
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
